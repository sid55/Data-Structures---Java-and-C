/**
 * Tree.java
 * 
 * This class is binary tree that uses nodes. Each node
 * has a value and a string. The string is the word from the textfile
 * and the value is a queue of integers. Each node also has a left 
 * and right node so that each node can access its right child and its
 * left child. Methods in this class include insert which inserts a string
 * into the binary tree and outputHelper which shows to the user in which
 * lines have certain words been written in the textfile.
 * 
 *Shown below are the book(s) I have used as a reference to copy code or change existing code.
 *There are more and better descriptions of the book(s) right above each of the methods where I used 
 *these recourses. As a brief summary though, here are the book(s) I have used. In this program, I only copied
 *the display forward method.
 *1)Data Structures and Algorithms in Java Second Edition
 */
import static java.lang.System.*;

class Tree {

    private class Node {
        String key;
        Queue<Integer> value;
        Node left;
        Node right;
    }
    private Node root;
    private int temp;
    private Node temp2;
    
    /**
	 * Source: Data Structures and Algorithms in Java Second Edition
	 * How I used the source: I used this book as a reference to help me
	 * 						  create this method. The changes I have made to
	 *  					  this method are that I had to format it to
	 *  					  be able to search for a string, not an integer.  
	 */
    public Node find(String key2){
    	Node current = root;
    	if(current!=null){
    	while(current.key.compareTo(key2)!=0){
    		if(key2.compareTo(current.key)>=1){
    			current = current.left;
    		} else {
    			current = current.right;
    		}
    		if (current == null){
    			return null;
    		}
    	}
    	}
    	return current;
    }
    
    private void debugHelper(Node tree, int depth) {
        // Your code here might be recursive
    	if (tree!=null){
    		String myStr = "";
    		for (int i = 0; i<depth*2 ; i++){
        		myStr = myStr.concat(" ");
        	}
    		debugHelper(tree.right, depth+1);
    		Node n = find(tree.key);
    		if (n!=null){
    		System.out.println(myStr + depth + " " + tree.key);
    		}
    		debugHelper(tree.left, depth+1);
    	}
        //throw new UnsupportedOperationException();
    }

    private void outputHelper(Node tree) {
        // Your code here might be recursive
    	   if (tree!=null){
    	   outputHelper(tree.right);
    	   Queue<Integer>.Itor iterator = (Queue<Integer>.Itor)tree.value.iterator();
    	   if (iterator.hasNext()){
    		   System.out.print(tree.key + " :");
    		   while (iterator.hasNext()){
        		   System.out.print(" " + iterator.next());
        	   }
    	   }
    	   System.out.println();
    	   outputHelper(tree.left);
    	   }
    	   //throw new UnsupportedOperationException();
    }
    
    public void printOut(int depth){
    	for (int i = 0; i<depth ; i++){
    		System.out.print(" ");
    	}
    }
    
    /**
  	 * Source: Data Structures and Algorithms in Java Second Edition
  	 * How I used the source: I used this book as a reference to help me
  	 * 						  create this method. The changes I have made to
  	 *  					  this method are that I had to format it to
  	 *  					  be able to search for a string, not an integer.  
  	 */
    public void insert(String key, Integer linenum){
        // Insert a word into the tree
    	Node temp = find (key);
    	if (temp!=null){
    		temp.value.insert(linenum);
    	}else {
    	Node newNode = new Node();
    	newNode.key = key;
    	newNode.value  = new Queue<Integer>();
    	if(root == null){
    		root = newNode;
    		newNode.value.insert(linenum);
    	}
    	else {
    		newNode.value.insert(linenum);
    		Node current = root;
			Node parent;
    		while (true){
    			parent = current;
    			if(key.compareTo(current.key) >= 1){
    				current = current.left;
    				if(current == null){
    					parent.left = newNode;
						return;
					}
    			}
    			else{
    				current = current.right;
    				if(current == null){
    					parent.right = newNode;
						return;
					}
    			}
    		
	    		}
    			}
    	}
    }

    public void debug() {
        // Show debug output of tree
        debugHelper(root, 0);
    }

    
   public void output() {
         //Show sorted words with lines where each word appears
        outputHelper(root);
    }

}
