/**
 * Queue.java
 * 
 * This class holds a queue for each node in Tree.java. This 
 * queue for each node is a linked list and contains integers. 
 * These integers are line numbers for wherever a word is found 
 * in a text file. This class holds methods such as insert and
 * isEmpty so that these methods can be implemented in Tree.java
 */
import java.util.Iterator;
import java.util.NoSuchElementException;

class Queue <Item> implements Iterable <Item> {

   private class Node {
      Item item;
      Node next;
   }
   private Node head = null;
   private Node tail = null;

   public boolean isempty() {
	   return (head==null);
   }
   
   public void insert(Item newitem) {
	   if (isempty()){
		   Node newNode = new Node();
		   newNode.item = newitem;
		   tail = newNode;
		   head = newNode;
	   }
	   else{
	   Node newNode = new Node();
	   newNode.item = newitem;
	   tail.next = newNode;
	   tail = newNode;
	   }
   }
   
   public void printOut(){
	   Node current = new Node();
	   current = head;
	   while(current!=null){
		   System.out.println(current.item);
		   current = current.next;
	   }
   }

   public Iterator <Item> iterator() {
      return new Itor ();
   }

   class Itor implements Iterator <Item> {
      Node current = head;
      public boolean hasNext() {
         return current != null;
      }
      public Item next() {
         if (! hasNext ()) throw new NoSuchElementException();
         Item result = current.item;
         current = current.next;
         return result;
      }
      public void remove() {
         throw new UnsupportedOperationException();
      }
   }

}
