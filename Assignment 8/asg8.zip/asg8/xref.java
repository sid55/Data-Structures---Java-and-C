/**
 * xref.java
 * 
 * This class functions as a main for the binary tree. It holds a method
 * which reads in each of the words of every line inside a text file and 
 * puts each of these strings into the binary tree. This class either runs
 * the program as is when given no arguments or runs the program in a 
 * debugging format if given the argument "-d". If run with the "-d" 
 * option, then this program will print a debug binary tree instead of
 * a report. A report of which words are on which lines will be printed 
 * if run without the "-d" argument. 
 */
import java.io.*;
import java.util.Scanner;
import static java.lang.System.*;

class xref {

    static void processFile(String filename, boolean debug) throws IOException {
        Scanner scan = new Scanner (new File(filename));
        Tree tree = new Tree();
        for (int linenr = 1; scan.hasNextLine (); ++linenr) {
            for (String word: scan.nextLine().split ("\\W+")) {
                //out.printf ("%s: %d: %s%n", filename, linenr, word);
                tree.insert(word, linenr);
            }
        }
        scan.close();
        if (debug) {
            tree.debug();
        } else {
            tree.output();
        }
    }

    public static void main(String[] args) {
        // This code handles -d option
    	if (args.length == 0){
       		System.err.println("You have not entered a filename");
       		System.exit(1);
    	}
    	
       	if(args.length == 1){	
    	try{
    		processFile(args[0],false);
    		System.exit(0);
       	}catch (IOException error){
    		System.err.println("You have not entered a correct filename");
    		System.exit(1);
    	}
       	}
    		
       	if (args.length == 2){
       	try{
       		if (args[0].compareTo("-d")!=0){
       			System.err.println("You have not entered a correct argument");
       			System.exit(1);
       		}
       		processFile(args[1],true);
       		System.exit(0);
       	}catch(IOException e){
       		System.err.println("You have not entered a correct filename");
    		System.exit(1);
       	}
    	} 
    	
    }   	
}

