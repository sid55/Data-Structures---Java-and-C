// dllistTest.java
// Unit tests for dllist

import org.junit.*; 
import static org.junit.Assert.assertEquals;

public class dllistTest {

    @Test
    public void startsEmptyTest() {
        dllist lst = new dllist();
        assertEquals(true, lst.isEmpty());
    }
    
    //step 9, need to check if it works
    @Test
    public void isEmpty(){
    	dllist lst = new dllist();
    	lst.insert("hi", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	assertEquals(false, lst.isEmpty());
    }
    
    @Test
    public void getItemAndInsertTest(){
    	dllist lst = new dllist();
    	lst.insert("hi", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	assertEquals("hi", lst.getItem());
    	lst.insert("hi2", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.insert("hi3", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	assertEquals("hi3", lst.getItem());
    }
    
    //12 - question vague about which position looking for
    @Test
    public void getItemAndInsert2Test(){
    dllist lst = new dllist();
	lst.insert("hi", dllist.position.FIRST);
	lst.setPosition(dllist.position.FIRST);
	lst.insert("hi2", dllist.position.FIRST);
	lst.setPosition(dllist.position.FIRST);
	assertEquals("hi2", lst.getItem());
    }
    
    //step 13 asking for a new unit test?
    @Test
    public void getItemAndInsert3Test(){
    	dllist lst = new dllist();
    	lst.insert("hi", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.insert("hi2", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.insert("hi3", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	assertEquals("hi3", lst.getItem());
    }
    
    //14
    @Test
    public void insertAtLastPosition(){
    	dllist lst = new dllist();
    	lst.insert("hi", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.insert("hi2", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.setPosition(dllist.position.FIRST);
    	assertEquals("hi", lst.getItem());
    }
    
    //14part2
    @Test
    public void insertAtFirstPositionTest(){
    	dllist lst = new dllist();
    	lst.insert("hi", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.insert("hi2", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.setPosition(dllist.position.LAST);
    	assertEquals("hi", lst.getItem());
    }
    
    //15
    @Test
    public void changePosition3Test(){
    	dllist lst = new dllist();
    	lst.insert("hi", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.insert("hi2", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.insert("hi3", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	assertEquals("hi3", lst.getItem());
    }
    
    //16 part1
    @Test
    public void insertBefore(){
    	dllist lst = new dllist();
    	lst.insert("A", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.insert("B", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.insert("C", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.insert("D", dllist.position.PREVIOUS);
    	lst.setPosition(dllist.position.PREVIOUS);
    	lst.setPosition(dllist.position.LAST);
    	assertEquals("C", lst.getItem());
    }
    
    //16 part2
    @Test
    public void insertAfter(){
    	dllist lst = new dllist();
    	lst.insert("A", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.insert("B", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.insert("C", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.insert("D", dllist.position.FOLLOWING);
    	lst.setPosition(dllist.position.FOLLOWING);
    	lst.setPosition(dllist.position.FIRST);
    	assertEquals("C", lst.getItem());
    }
    
    //18
    @Test
    public void insertOwn5(){
    	dllist lst = new dllist();
    	lst.insert("A", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.insert("B", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.insert("C", dllist.position.FOLLOWING);
    	lst.setPosition(dllist.position.FOLLOWING);
    	lst.insert("D", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.insert("E", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.setPosition(dllist.position.FIRST);
    	assertEquals("B", lst.getItem());
    	lst.setPosition(dllist.position.FOLLOWING);
    	assertEquals("C", lst.getItem());
    	lst.setPosition(dllist.position.FOLLOWING);
    	assertEquals("A", lst.getItem());
    	lst.setPosition(dllist.position.FOLLOWING);
    	assertEquals("D", lst.getItem());
    	lst.setPosition(dllist.position.FOLLOWING);
    	assertEquals("E", lst.getItem());
    }
    
    @Test
    public void insertOwn5Part2(){
    	dllist lst = new dllist();
    	lst.insert("A", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.insert("B", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.insert("C", dllist.position.FOLLOWING);
    	lst.setPosition(dllist.position.FOLLOWING);
    	lst.insert("D", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.insert("E", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	assertEquals("E", lst.getItem());
    	lst.setPosition(dllist.position.PREVIOUS);
    	assertEquals("D", lst.getItem());
    	lst.setPosition(dllist.position.PREVIOUS);
    	assertEquals("A", lst.getItem());
    	lst.setPosition(dllist.position.PREVIOUS);
    	assertEquals("C", lst.getItem());
    	lst.setPosition(dllist.position.PREVIOUS);
    	assertEquals("B", lst.getItem());
    }
    
    @Test
    public void insertOwn5Part3(){
    	dllist lst = new dllist();
    	lst.insert("A", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.insert("B", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.insert("C", dllist.position.FOLLOWING);
    	lst.setPosition(dllist.position.FOLLOWING);
    	lst.insert("D", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.insert("E", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.setPosition(dllist.position.PREVIOUS);
    	assertEquals("D", lst.getItem());
    	lst.setPosition(dllist.position.FOLLOWING);
    	assertEquals("E", lst.getItem());
    	lst.setPosition(dllist.position.FIRST);
    	assertEquals("B", lst.getItem());
    	lst.setPosition(dllist.position.FOLLOWING);
    	lst.setPosition(dllist.position.FOLLOWING);
    	assertEquals("A", lst.getItem());
    	lst.setPosition(dllist.position.PREVIOUS);
    	assertEquals("C", lst.getItem());
    }
    
    //20
    @Test
    public void getPositionTestAndInsertOwn5SimilarTest(){
    	dllist lst = new dllist();
    	lst.insert("A", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.insert("B", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.insert("C", dllist.position.FOLLOWING);
    	lst.setPosition(dllist.position.FOLLOWING);
    	lst.insert("D", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.insert("E", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.setPosition(dllist.position.FIRST);
    	assertEquals(0, lst.getPosition());
    	lst.setPosition(dllist.position.FOLLOWING);
    	assertEquals(1, lst.getPosition());
    	lst.setPosition(dllist.position.FOLLOWING);
    	assertEquals(2, lst.getPosition());
    	lst.setPosition(dllist.position.FOLLOWING);
    	assertEquals(3, lst.getPosition());
    	lst.setPosition(dllist.position.FOLLOWING);
    	assertEquals(4, lst.getPosition());
    }
    
    //21 
    @Test
    public void insertOwn5Similar2(){
    	dllist lst = new dllist();
    	lst.insert("A", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.insert("B", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.insert("C", dllist.position.FOLLOWING);
    	lst.setPosition(dllist.position.FOLLOWING);
    	lst.insert("D", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.insert("E", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	assertEquals(4, lst.getPosition());
    	lst.setPosition(dllist.position.PREVIOUS);
    	assertEquals(3, lst.getPosition());
    	lst.setPosition(dllist.position.PREVIOUS);
    	assertEquals(2, lst.getPosition());
    	lst.setPosition(dllist.position.PREVIOUS);
    	assertEquals(1, lst.getPosition());
    	lst.setPosition(dllist.position.PREVIOUS);
    	assertEquals(0, lst.getPosition());
    }
    
    //22
    @Test
    public void deleteTest(){
    	dllist lst = new dllist();
    	lst.insert("A", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.insert("B", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.insert("C", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.insert("D", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.insert("E", dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    	lst.setPosition(dllist.position.LAST);
    }
    
    //23 //set following exception
    @Test (expected=Exception.class)
    public void error1Test() throws NullPointerException{
    	dllist lst = new dllist();
    	lst.insert("A", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.setPosition(dllist.position.FOLLOWING);
    }
    
    //23 //set previous exception
    @Test (expected=Exception.class)
    public void error2Test() throws UnsupportedOperationException{
    	dllist lst = new dllist();
    	lst.insert("A", dllist.position.FIRST);
    	lst.setPosition(dllist.position.FIRST);
    	lst.setPosition(dllist.position.PREVIOUS);
    }
    //23 //set first exception
    @Test (expected=Exception.class)
    public void error3Test() throws UnsupportedOperationException{
    	dllist lst = new dllist();
    	lst.setPosition(dllist.position.FIRST);
    }
    
    //23 //set last exception
    @Test (expected=Exception.class)
    public void error4Test() throws UnsupportedOperationException{
    	dllist lst = new dllist();
    	lst.setPosition(dllist.position.LAST);
    }
    
    @Test (expected=Exception.class)
    public void error5Test() throws UnsupportedOperationException{
    	dllist lst = new dllist();
    	lst.setPosition(dllist.position.FOLLOWING);
    }
    
    @Test (expected=Exception.class)
    public void error6Test() throws UnsupportedOperationException{
    	dllist lst = new dllist();
    	lst.setPosition(dllist.position.PREVIOUS);
    }
    
    //23 //get position error
    @Test (expected=Exception.class)
    public void error7Test() throws UnsupportedOperationException{
    	dllist lst = new dllist();
    	lst.getPosition();
    }
    
    //23 //delete exception
    @Test (expected=Exception.class)
    public void error8Test() throws UnsupportedOperationException{
    	dllist lst = new dllist();
    	lst.delete();
    }
    
    @Test (expected=Exception.class)
    public void error9Test() throws UnsupportedOperationException{
    	dllist lst = new dllist();
    	lst.getItem();
    }
    
    
}
