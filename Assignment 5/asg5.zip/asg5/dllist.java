
// dllist.java 
// Template code for doubly-linked list of strings.
/**
 *Shown below are the book(s) I have used as a reference to copy code or change existing code.
 *There are more and better descriptions of the book(s) right above each of the methods where I used 
 *these recourses. As a brief summary though, here are the book(s) I have used. In this program, I only copied
 *the display forward method.
 *1)Data Structures and Algorithms in Java Second Edition
 */
import java.io.*;
import java.util.*;

public class dllist {

	public enum position {
		FIRST, PREVIOUS, FOLLOWING, LAST
	};

	private class node {
		String item;
		node prev;
		node next;

		public node(String sent) {
			prev = null;
			next = null;
			item = sent;
		}

		public node() {
			// TODO Auto-generated constructor stub
		}

		//DELETE LATER
		public void showNode() {
			System.out.println(item + " ");
		}
	}

	private node first = null;
	private node current = null;
	private node last = null;
	private int currentPosition = 0;
	
	/**
	 * Source: Data Structures and Algorithms in Java Second Edition
	 * How I used the source: I copied this method from the book to display each of the
	 * 							nodes in the linked list. This also gave me a better 
	 * 							understanding of how to use nodes and in return helped
	 * 							me code the other methods.  
	 */
	public void displayForward() {
		System.out.println("node (first-->last): ");
		node current = first;
		while (current != null) {
			current.showNode();
			current = current.next;
		}
		System.out.println("");
	}

	public void setPosition(position pos) throws UnsupportedOperationException {
		switch (pos) {
		case FIRST: 
			if(isEmpty() == true){
				throw new UnsupportedOperationException();
			}
			currentPosition = 0;
			//System.out.println("method pass 1 current is now: " + getItem());
			current = first;
			//System.out.println("method pass 2 current is now: " + getItem());
			if (first == null)
				currentPosition = -1;
			else
				break;
			return;
		case PREVIOUS:
			if (current.prev == null || isEmpty()==true){
				throw new UnsupportedOperationException();
			}
			if (current != null) {
				currentPosition -= 1;
				current = current.prev;
			} else
				break;
			return;
		case FOLLOWING:
			if (current.next == null || isEmpty()==true){
				throw new UnsupportedOperationException();
			}
			else if (current != null) {
				currentPosition += 1;
				current = current.next;
			} else
				break;
			return;
		case LAST:
			if(isEmpty() ==true){
				throw new UnsupportedOperationException();
			}
			node temp = first;
			currentPosition = 0;
			if (temp != null)
				while (temp.next != null) {
					temp = temp.next;
					currentPosition += 1;
				}
			else {
				currentPosition = -1;
				break;
			}
			current = temp;
			return;
		default:
			throw new UnsupportedOperationException();
			//break;
		}
		//throw new NoSuchElementException();
	}

	public boolean isEmpty() {
		return first == null;
	}

	public String getItem() throws UnsupportedOperationException { 
		if(isEmpty() == true){
		throw new UnsupportedOperationException();
		}
		else{
		return current.item;
		}
		}
	
	  public int getPosition () throws UnsupportedOperationException { 
		  if(isEmpty() == true){
		  throw new UnsupportedOperationException();
		  }
		  else{
			  return currentPosition;
		  }
		  }
	 
	  
	 public void delete () throws UnsupportedOperationException{ 
		 if(isEmpty() == true){
			 throw new UnsupportedOperationException();
		 }
		 else if (current.next == null){
			 last = last.prev;
			 current = current.prev;
			 current.next = null;
			 last.next = null;
		 }
		 else if(current.next != null){
		 node after = current.next;
		 node previous = current.prev;
		 previous.next = after;
		 after.prev = previous;
		 current = after;
		 }  
		 }
	 

	// pos will give us integer currentPosition
	public void insert(String item, position pos) throws UnsupportedOperationException {
		node newNode = new node(item);
		if (isEmpty()) {
			first = newNode;
			last = first;
			currentPosition = 0;
			current = first;
			newNode.prev = null;
			newNode.next = null;
		} else {
			// case for inster in first
			if (pos == position.FIRST) {
				newNode.next = first;
				newNode.prev = null;
				first.prev = newNode;
				first = newNode;
				currentPosition++;
			} else if (pos == position.PREVIOUS) {
				if (current.prev == null) {
					insert(item, position.FIRST);
				} else {
					current.prev.next = newNode;
					newNode.prev = current.prev;
					newNode.next = current;
					current.prev = newNode;
					currentPosition++;
				}
			} else if (pos == position.FOLLOWING) {
				if (current.next == null) {
					insert(item, position.LAST);
				} else {
					current.next.prev = newNode;
					newNode.next = current.next;
					newNode.prev = current;
					current.next = newNode;
				}
			} else if (pos == position.LAST) {
				newNode.prev = last;
				newNode.next = null;
				last.next = newNode;
				last = newNode;
			} else {
				throw new UnsupportedOperationException();	
			}
		}
	}

}
