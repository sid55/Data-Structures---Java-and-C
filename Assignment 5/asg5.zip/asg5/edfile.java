// edfile.java 
// Template for a line-oriented text editor inspired by ed.

import java.util.Scanner; 

import javax.swing.event.ListSelectionEvent;

import static java.lang.System.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;

class edfile{

	static File file2;
	static String myFileArg;
	static String myArg;

public static void main (String[] args) throws IOException {
	  if(args.length == 2 && args[0].compareTo("-e")==0){
		  System.out.println(args[1]);
	  }
	  System.out.println("Welcome to the program");
	  boolean want_echo = true;
      dllist lines = new dllist ();
      
      if(args.length!=0){
      String partOne = args[0];
      if (args.length == 2){
      String partTwo = args[1];
      
      //if(partTwo!=null){
    	  try{
    		  partTwo = args[1];
    		  if(partOne.compareTo("-e")==0 || partOne.compareTo(partTwo)==0){
        	  myArg = "-e";
    		  }
    		  else{
    			  throw new Exception();
    		  }
    	  }
          catch(Exception e) {
        	  System.out.println("You have not entered the -e argument. Please restart the program with correct argument(s)");
        	  System.exit(1);
          }
      //}
      //else{
    	  //myArg = "";
      //}
      //if(partOne.compareTo("-e")==0 || partOne.compareTo(args[0])==0){
    	 //has filename
    	  try{
    	  if(args[0].compareTo("-e")==0){
    	  File file = new File(args[1]);
    	  justFile(file, args[1]);
    	  }
    	  else{
    		  File file = new File(args[0]);
    		  justFile(file, args[0]);
    	  }
    	  readFile(file2, lines);
    	  } catch(Exception e){
    		  System.out.println("You have not entered a real filename. Please restart the program with correct argument");
    		  System.exit(1);
    	  }
      }
      }
      if(args.length == 1 && args[0].compareTo("-e")!=0){
    	  try{
    	  File file = new File(args[0]);
    	  justFile(file, args[0]);
		  readFile(file2, lines);
		  myArg = "";
    	  } catch (Exception e){
    		  System.out.println("You have not entered a real filename. Please restart program with correct argument");
    		  System.exit(1);
    	  }
      }
      if(args.length == 1 && args[0].compareTo("-e")==0){
    	  myArg = "-e";
      }
      if(args.length == 0){
    	  myArg = "";
      }
      
      
	      Scanner stdin = new Scanner (in);
	      for (;;) {
	         if (! stdin.hasNextLine()) break;
	         String inputline = stdin.nextLine();
	         //if (want_echo) out.printf ("%s%n", inputline);
	         if (inputline.matches ("^\\s*$")) continue;
	         char command = inputline.charAt(0);
	         switch (command) {
	            case '#': break;
	            case '$': 	if(myArg.compareTo("-e")==0){
	            			System.out.println("$");
	            			lines.setPosition(dllist.position.LAST);
	            			System.out.println("New current line: " + lines.getItem());
	            			} else if (myArg.compareTo("")==0){
	            				lines.setPosition(dllist.position.LAST);
		            			System.out.println("New current line: " + lines.getItem());
	            			}
	            			break;
	            case '*': 	if(myArg.compareTo("-e")==0){
	            			System.out.println("*");
	            			lines.displayForward(); //change later, cant use method
	            			} else if (myArg.compareTo("")==0){
	            				lines.displayForward(); 
	            			}
	            			break;
	            case '.':   if(myArg.compareTo("-e")==0){
	            			System.out.println(".");
	            			System.out.println("Current line: " + lines.getItem());
	            			} else if (myArg.compareTo("")==0){
	            				System.out.println("Current line: " + lines.getItem());
	            			}
	            			break;
	            case '0': 	if(myArg.compareTo("-e")==0){
	            			System.out.println("0");
	            			lines.setPosition(dllist.position.FIRST);
    						System.out.println("New current line: " + lines.getItem());
	            			} else if (myArg.compareTo("")==0){
	            				System.out.println("0");
		            			lines.setPosition(dllist.position.FIRST);
		            			System.out.println("New current line: " + lines.getItem());
	            			}
	            			break;
	            case '<':   if(myArg.compareTo("-e")==0){
	            			System.out.println("<");
	            			lines.setPosition(dllist.position.PREVIOUS);
	            			System.out.println("New current line: " + lines.getItem());
	            			} else if (myArg.compareTo("")==0){
	            				lines.setPosition(dllist.position.PREVIOUS);
	            				System.out.println("New current line: " + lines.getItem());
	            			}
	            			break;
	            case '>': 	if(myArg.compareTo("-e")==0){
	            			System.out.println(">");
	            			lines.setPosition(dllist.position.FOLLOWING);
	            			System.out.println("New current line: " + lines.getItem());
	            			} else if (myArg.compareTo("")==0){
	            				lines.setPosition(dllist.position.FOLLOWING);
	            				System.out.println("New current line: " + lines.getItem());
	            			}
	            			break;
	            case 'a':   if(myArg.compareTo("-e")==0){
	            			System.out.println("a");
	            			String text = inputline.substring(1, inputline.length());
	            			lines.insert(text, dllist.position.FOLLOWING);
	            			lines.setPosition(dllist.position.FOLLOWING);
	            			System.out.println("New current line: " + lines.getItem());
	            			} else if (myArg.compareTo("")==0){
	            				String text = inputline.substring(1, inputline.length());
		            			lines.insert(text, dllist.position.FOLLOWING);
		            			lines.setPosition(dllist.position.FOLLOWING);
		            			System.out.println("New current line: " + lines.getItem());
	            			}
	            			break;
	            case 'd':   if(myArg.compareTo("-e")==0){
	            			System.out.println("d");
	            			lines.delete();
	            			} else if (myArg.compareTo("")==0){
	            				lines.delete();
	            			}
	            			break;
	            case 'i':   if(myArg.compareTo("-e")==0){
	            			System.out.println("i");
	            			String text2 = inputline.substring(1, inputline.length());
    						lines.insert(text2, dllist.position.PREVIOUS);
    						lines.setPosition(dllist.position.PREVIOUS);
    						System.out.println("New current line: " + lines.getItem());
	            			} else if (myArg.compareTo("")==0){
	            				String text2 = inputline.substring(1, inputline.length());
	    						lines.insert(text2, dllist.position.PREVIOUS);
	    						lines.setPosition(dllist.position.PREVIOUS);
	    						System.out.println("New current line: " + lines.getItem());
	            			}
	            			break;
	            case 'r':   if(myArg.compareTo("-e")==0){
	            			System.out.println("r");
	            			String myFileTemp = inputline.substring(1, inputline.length());
	            			readFile2(new File(myFileTemp), lines);
	            			} else if (myArg.compareTo("")==0){
	            				String myFileTemp = inputline.substring(1, inputline.length());
	            				readFile2(new File(myFileTemp), lines);
		 
	            			}
	            			break;
	            case 'w': 	if(myArg.compareTo("-e")==0){
	            			String fileNAMME = inputline.substring(1, inputline.length());
	            			System.out.println("w" + fileNAMME);
	                			PrintWriter myWrite = new PrintWriter(fileNAMME);
	                	    	  Scanner sc = new Scanner(System.in);
	                	    	  while(sc.hasNextLine()){
	                	    		  String temp = sc.nextLine();
	                	    		  if (sc.hasNextLine()==false){
	                	    			  myWrite.println(temp);
	                	    			  myWrite.close();
	                	    			  break;
	                	    		  }
	                	    		  myWrite.println(temp);
	                	    	  }
	                	    	  justFile(fileNAMME);
	                	    	  readFileW2(new File(fileNAMME), lines);
	                	    	  
	                		
	            			}  if (myArg.compareTo("")==0){
	            				//if(args[1].compareTo("")==0){
	            					String fileNAMME = inputline.substring(1, inputline.length());
	            							//inputline.split(" ")[1];
	            	    			PrintWriter myWrite = new PrintWriter(fileNAMME);
	            	    	    	  Scanner sc = new Scanner(System.in);
	            	    	    	  while(sc.hasNextLine()){
	            	    	    		  String temp = sc.nextLine();
	            	    	    		  if (sc.hasNextLine()==false){
	            	    	    			  myWrite.println(temp);
	            	    	    			  myWrite.close();
	            	    	    			  break;
	            	    	    		  }
	            	    	    		  myWrite.println(temp);
	            	    	    	  }
	            	    	    	  justFile(fileNAMME);
	            	    	    	  readFileW(new File(fileNAMME), lines);
	            	    		//}
	            			}
	            			break;
	            default : 	System.out.println("You have entered the " + command + " command. It does nothing. Please re-enter another command."); 
	            			break;
	         }
	      }
	      //do a .close
	      
	      System.out.println("You have finished editing your text file. Thank you for using this editor. Bye.");
	      System.exit(0);
	      //DONE CORRECTLY???? auxlib.STUB ("(eof)");
	   }
	
   
   public static File justFile(File myFile, String temp){
	   myFileArg = temp;
	   file2 = new File(temp);
	   return file2;
   }
   
   public static File justFile(String temp){
	   myFileArg = temp;
	   file2 = new File(temp);
	   return file2;
   }
   
   public static void readFile(File myFile, dllist lines) throws IOException{
	   FileReader fileReader = new FileReader(myFile);
	   BufferedReader bRead = new BufferedReader(fileReader);
	   Scanner sc = new Scanner(System.in);
	   String line = bRead.readLine();
	   System.out.println("These are the nodes in your linked list:");
	   while(line!=null){
		   while(line.compareTo("") == 0){
			   line = bRead.readLine();
		   }
		   lines.insert(line, dllist.position.LAST);
		   lines.setPosition(dllist.position.LAST);
		   System.out.println(lines.getItem());
		   line = bRead.readLine();
	   }
   }
   
   public static void readFileW2(File myFile, dllist lines) throws IOException{
	   FileReader fileReader = new FileReader(myFile);
	   BufferedReader bRead = new BufferedReader(fileReader);
	   Scanner sc = new Scanner(System.in);
	   int counter = 0;
	   String line = bRead.readLine();
	   System.out.println("These are the nodes in your linked list:");
	   while(line!=null){
		   while(line.compareTo("") == 0){
			   line = bRead.readLine();
		   }
		   lines.insert(line, dllist.position.LAST);
		   lines.setPosition(dllist.position.LAST);
		   System.out.println(lines.getItem());
		   counter++;
		   line = bRead.readLine();
	   }
	   System.out.println("The number of lines in the file is " + counter);
   }
   
   //Specific for no -e option
   public static void readFileW(File myFile, dllist lines) throws IOException{
	   FileReader fileReader = new FileReader(myFile);
	   BufferedReader bRead = new BufferedReader(fileReader);
	   Scanner sc = new Scanner(System.in);
	   int counter = 0;
	   String line = bRead.readLine();
	   while(line!=null){
		   while(line.compareTo("") == 0){
			   line = bRead.readLine();
		   }
		   lines.insert(line, dllist.position.LAST);
		   lines.setPosition(dllist.position.LAST);
		   counter++;
		   line = bRead.readLine();
	   }
	   System.out.println("The number of lines in the file is " + counter);
   }
   
   //Specific for one of the commands
   public static void readFile2(File myFile, dllist lines) throws IOException{
	   FileReader fileReader = new FileReader(myFile);
	   BufferedReader bRead = new BufferedReader(fileReader);
	   Scanner sc = new Scanner(System.in);
	   int counter = 0;
	   String line = bRead.readLine();
	   while(line!=null){
		   while(line.compareTo("") == 0){
			   line = bRead.readLine();
		   }
		   lines.insert(line, dllist.position.FOLLOWING);
		   lines.setPosition(dllist.position.FOLLOWING);
		   counter++;
		   line = bRead.readLine();
	   }
	   System.out.println("The number of lines inserted is " + counter);
   }
   
}

