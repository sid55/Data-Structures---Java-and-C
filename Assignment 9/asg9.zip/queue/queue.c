//queue.c
//This holds a queue for this c program. This queue has methods such as
//insert, remove, and checking if the queue is empty or not. It also
//initializes the queue.


#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "queue.h"

#define STUBPRINTF(...) fprintf(stderr, __VA_ARGS__);

/* Internal implementation definitions */
struct queue_node {
   queue_item_t item;
   struct queue_node *link;
};

typedef struct queue_node queue_node;

struct queue {
   queue_node *front;
   queue_node *rear;
};

/* Functions */

queue *queue_new(void) {
	struct queue *n;
	n = (struct queue *)malloc(sizeof(struct queue));
	n->front = NULL;
	n->rear = NULL;
    return n;
}

void queue_free(queue *this) {
   assert(queue_isempty(this));
   free(this);
}

void queue_insert(queue *this, queue_item_t item) {
	//struct node *n;
	// n = (struct node *)malloc(sizeof(struct node));
   if(queue_isempty(this)){
	   struct queue_node *n;
	   n = (struct queue_node *)malloc(sizeof(struct queue_node));
	   n->item = item;
	   n->link = NULL;
	   this->front = n;
	   this->rear = n;
   }else{
   struct queue_node *n;
   n = (struct queue_node *)malloc(sizeof(struct queue_node));
   n->item = item;
   n->link = NULL;
   this->rear->link = n;
   this->rear = n;
   }
}

queue_item_t queue_remove(queue *this) {
   assert(!queue_isempty(this));
   /*
   struct queue_node *n;
   n = this->front;
   this->front = this->front->link;
   return n->item;
   free(n);
   */

   if(this->front->link == NULL){
	   char *temp;
	   temp = this->front->item;
	   queue_node *n;
	   n = this->front;
	   //this->front = this->front->link;
	   free(n);
	   this->front = NULL;
	   this->rear = NULL;
	   return temp;
   }else{
	char *temp;
	temp = this->front->item;
   queue_node *n;
   n = this->front;
   this->front = this->front->link;
   free(n);
   return temp;
   }
}

bool queue_isempty(queue *this) {
   return this->front == NULL;
}
