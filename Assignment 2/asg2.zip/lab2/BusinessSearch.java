import java.util.*;
import java.io.*;
/**
 *This program asks the user to input a name such as a business's name and it will
 *return the business's phone number. If the business can not be found,
 *the program will say that the number is "NOT FOUND." There are also 
 *counters to keep track of how many numbers were found and how many were not.
 *
 *Shown below are the websites and books I have used as a reference to copy code or change existing code.
 *There are more and better descriptions of the websites right above each of the methods where I used 
 *these recourses. As a brief summary though, here are the links/books I have used:
 *1)http://codereview.stackexchange.com/questions/64711/merge-sort-an-integer-array
 *2)http://stackoverflow.com/questions/20795158/sorting-names-using-merge-sort
 *3)Data Structures and Algorithms in Java Second Edition
 */
public class BusinessSearch {
	public static void main(String[] args) throws FileNotFoundException {
		
		Scanner sc = new Scanner (System.in);
		int counterOne = 0;
		int counterTwo = 0;
	
		if(args.length ==0){
			System.out.println("USAGE: BusinessSearch businessDB");
			System.exit(0);
		}
		    String filename = args[0];
		    File file = new File(filename);
		    //if(args[0]==null){
		    	//System.out.println("Put in a file argument");
		    //}
		//}
		//else {
		//File file = new File("business.txt");
		//}
			
		try {
			BusinessSearch bs = new BusinessSearch();
			bs.readFileReal(file);
			bs.mergeSort(myArray);
			bs.noNumArray(myArray);
			bs.mergeSort(secArray);
			
			while(true){
				String searchKey = sc.nextLine();
				if (searchKey.compareTo("")==0){
					break;
				}
				else if (bs.binarySearch(searchKey)==-1) {
					System.out.println("NOT FOUND");
					counterTwo++;
				}
				else {
				System.out.println(myArray[bs.binarySearch(searchKey)].split(",")[1]);
				counterOne++;
				}
				}
			
			System.out.println(counterOne + " total queries, " + counterTwo + " not found");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

private static String[] secArray;;  //maybe static
private static String[] myArray;

/**
 * Constructor of this program
 */
public BusinessSearch(){
	
}

/**
 * This method reads in the file using a BufferedReader
 * and puts each line of the file into the next index location 
 * of an array
 * @param file - the name of the file that has the businesses and their numbers
 * @throws IOException - an exception that gets thrown when the file cannot be inputed
 */
private void readFileReal(File file) throws IOException{
	try{
	   FileReader fileReader = new FileReader(file);
	   BufferedReader bufferedReader = new BufferedReader(fileReader);	
	   String line;
	   String line2 = bufferedReader.readLine();
	   int x = Integer.parseInt(line2);
	   myArray = new String [x];
	   int r = 0;
	   while ((line = bufferedReader.readLine()) != null) {
		   myArray[r] = line;
		   r++;
	   }
	   r--;
	   fileReader.close();
	} catch (IOException i) {
		i.printStackTrace();
	}
}

/**
 * This method separates the input array into two different 
 * arrays. The first array is for all the elements to the right of the array
 * and the second array is for all the elements to the left of
 * the array. This method then recursively keep separating the elements and then
 * recursively calls the merge method.
 * @param names - the input array that has the list of business names and each of their numbers
 * 
 * 
 * Website URL: http://codereview.stackexchange.com/questions/64711/merge-sort-an-integer-array
 * Author: Arun Prakash
 * 
 * Website URL: http://stackoverflow.com/questions/20795158/sorting-names-using-merge-sort
 * Author: jarnthrax
 * 
 * What I used and changed: After looking at both these websites as to how they mergesorted the array, I have
 * 							tried to create the code myself and came to the code shown below. I have noticed though,
 * 							that after I was done, my code looks similar to a mix of both of these websites so I 
 * 							thought I should give them credit for helping me figure out how to make the method.
 */
public void mergeSort(String[] names) {
	if (names.length < 2){
		return;
	}
    if (names.length >= 2) {
    	int mid = names.length/2;
    	int rightSize = names.length - mid;
        String[] left = new String[mid];
        String[] right = new String[rightSize];

        for (int i = 0; i < left.length; i++) {
            left[i] = names[i];
        }

        for (int j = 0; j < right.length; j++) {
        	int x = j + mid;
            right[j] = names[x];
        }

        mergeSort(left);
        mergeSort(right);
        merge(names, left, right);
    }
}

/**
 * This method merges the values from both arrays into the array names
 * while at the same time incrementing the index pointer of the names,
 * left, and right arrays
 * @param names - the resulting array after merging both the left and right arrays
 * @param left - the left half of values of the names array put into this array
 * @param right - the right half of values of the names array put into this array
 * 
 * 
 * Website URL: http://stackoverflow.com/questions/20795158/sorting-names-using-merge-sort
 * Author: Unknown
 * What I used and changed: I used the method of merge from this website but edited the if statement
 * 				a little bit. Instead of the method compareToIgnoreCase, I used 
 * 				the method compareTo.
 */
public void merge(String[] names, String[] left, String[] right) {
    int a = 0;
    int b = 0;
    for (int i = 0; i < names.length; i++) {
        if (b >= right.length || (a < left.length && left[a].compareTo(right[b]) < 0)) {
            names[i] = left[a];
            a++;
        } else {
            names[i] = right[b];
            b++;
        }
    }
}

/**
 * This method puts just the names of each business 
 * into a new array
 * @param myArray -the array with the names of the businesses and each of their numbers
 */
public void noNumArray(String[] myArray)
{
	int temp = myArray.length;
    secArray = new String[temp];
    for(int i=0; i<myArray.length; i++)
    {
        secArray[i] = myArray[i].split(",")[0];
    }
}

/**
 * This method does a binary search for the names of the businesses
 * in order to find and return the index location of where
 * that business is located in the array
 * @param searchKey - an array with just the names of the businesses
 * @return - the index location of where the business name is located in the array
 * 
 * 
 * Book: Data Structures and Algorithms in Java Second Edition
 * Author: Robert Lafore
 * What I used and changed: From this book, I have used the binarysearch code. However, the stuff
 * 							I had to change on this code were the statements in the if statements. I had 
 * 							to do this to accommodate searching through an array of strings instead of integers
 * 							and also make my binarysearch such that it would return the index at which the 
 * 							business name is located instead of returning the actual name.
 */
private int binarySearch(String searchKey){
	int nElems = secArray.length; 
	int lowerbound = 0;
	int upperbound = nElems -1;  
	int curIn;
	while (true){
		curIn = (lowerbound + upperbound) / 2;
		if(secArray[curIn].compareTo(searchKey)==0){
			return curIn;
		}
		else if (lowerbound > upperbound){ 
			return -1;
		}
		else
		{
			if(secArray[curIn].compareTo(searchKey) < 0){
				lowerbound = curIn +1;
			}
			else{
				upperbound = curIn -1;
			}
		}
	}
}

}

