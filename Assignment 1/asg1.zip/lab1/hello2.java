/**
 * Filename: hello2
 * File's Role: This class was built to satisfy the requirement
 * of creating a separate class that prints out a witty quote.
 * This class prints out the statement "An apple a day
 * keeps the doctor away."
 * Special Instructions: None
 *
 */
class hello2 {
public static void main (String[] args){
	System.out.println("An apple a day keeps the doctor away.");
}
}
