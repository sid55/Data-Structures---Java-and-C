// Calc.java 
// Define a class for doing RPN.
 /*
 *Shown below are the website(s)/book(s) I have used as a reference to copy code or change existing code.
 *There are more and better descriptions of the website(s)/book(s) right above each of the methods where I used 
 *these recourses. As a brief summary though, here are the link(s)/book(s) I have used:
 *1) Data Structures and Algorithms in Java Second Edition
 */
import java.util.*;
import java.io.*;
public class Calc {
	
	double[] myArray = new double[100];
	int top = -1;
	
    // Constructor
    public Calc() {
    }
    
    // Push a number
    /**
     * @param x - number being pushed into the stack
     * @throws IndexOutOfBoundsException - exception thrown when there is an index out of bounds error
     * 
     * Book: Data Structures and Algorithms in Java Second Edition
     * Author: Robert Lafore
     * What I used and changed: I used the code that this author had shown in the book for the push method
     * 							However, I additionally added the throwing of the exception into the code.
     */
    public void push(double x) throws IndexOutOfBoundsException{
    	myArray[++top] = x;
    }
    
    // Pop top number (removes)
    /**
     * @return - the element at the index position of the array
     * 
     * Book: Data Structures and Algorithms in Java Second Edition
     * Author: Robert Lafore
     * What I used and changed: I used the code that this author had shown in the book for the pop method. 
     * 							However, I additionally added the throwing of the exception into the code.
     */
    public double pop() {
    		int x = top--;
    		if (x<0){
    			throw new IndexOutOfBoundsException("You are out of bounds!");
    		}
    		return myArray[x];
    	}
    
    // Peek at top number (does not remove)
    /**
     * @return - the element at the index position of the array
     * @throws Exception - exception thrown where there is an error
     */
    public double peek() throws IndexOutOfBoundsException{
    	return myArray[top];
    }
    
    // Add top two numbers
    /**
     * @throws IndexOutOfBoundsException - exception thrown when there is an index out of bounds error
     */
    public void add() throws IndexOutOfBoundsException{
    		double x = pop();
    		double y = pop();
    		double z = x + y;
    		push(z);
    }
    
    // Subtract top two numbers (top on right side)
    /**
     * @throws IndexOutOfBoundsException - exception thrown when there is an index out of bounds error
     */
    public void subtract() throws IndexOutOfBoundsException {
    		double x = pop();
    		double y = pop();
    		double z = y - x;
    		push(z);
    }

    // Multiply top two numbers
    /**
     * @throws IndexOutOfBoundsException - exception thrown when there is an index out of bounds error
     */
    public void multiply() throws IndexOutOfBoundsException {
    		double x = pop();
    		double y = pop();
	    	double z = x * y;
	    	push(z);
    }
    
    // Divide top two numbers (top on bottom)
    /**
     * @throws IndexOutOfBoundsException - exception thrown when there is an index out of bounds error
     */
    public void divide() throws IndexOutOfBoundsException, IllegalArgumentException{
    		double x = pop();
    		if(x==0){
    			throw new IllegalArgumentException("Can't divide by 0");
    		}
    		double y = pop();
    		double z = y/x;
    		push(z);
    }
    
    // Return how many numbers are in the stack
    /**
     * @return - the length of how big the stack is
     */
    public int depth() throws IndexOutOfBoundsException{
    	return (top+1);
    }
    
    /**
     * This method calculates the log base 2 of the number at the top of the stack
     * @throws IndexOutOfBoundsException - exception thrown when there is an index out of bounds error
     */
    public void log2() throws IndexOutOfBoundsException{
    	double x = pop();
    	double y = (Math.log(x))/(Math.log(2));
    	push(y);
    }
}

